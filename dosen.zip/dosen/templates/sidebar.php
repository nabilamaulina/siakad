<?php
// dosen/templates/sidebar.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$current_page = basename($_SERVER['PHP_SELF']);

// Ambil info nama dosen dan data session aktif
$nama_dosen_aktif = $user_dosen['nama_dosen'] ?? $_SESSION['nama_user'] ?? 'Dosen Pengajar';

// Deteksi lokasi folder saat ini agar link navigasi tidak pecah/salah jalur
$request_uri = $_SERVER['REQUEST_URI'];
$is_inside_folder = (strpos($request_uri, '/akademik_mengajar/') !== false || 
                     strpos($request_uri, '/perwalian/') !== false || 
                     strpos($request_uri, '/tugas_akhir/') !== false || 
                     strpos($request_uri, '/kinerja_dosen/') !== false);

// Path acuan mundur ke folder utama jika sedang berada di dalam sub-folder
$base_path = $is_inside_folder ? '../' : '';

// SOLUSI ERROR $db: Cek otomatis koneksi database agar tidak 'Undefined variable $db'
if (!isset($db)) {
    $config_path = $is_inside_folder ? __DIR__ . '/../../config/database.php' : __DIR__ . '/../config/database.php';
    if (file_exists($config_path)) {
        require_once $config_path;
    }
}
?>
<style>
    #sidebar-wrapper {
        min-height: 100vh;
        width: 260px;
        background-color: #245358; 
        border-right: 1px solid rgba(255, 255, 255, 0.05);
        transition: all 0.3s;
        flex-shrink: 0;
    }
    
    .user-profile-sidebar {
        display: block;
        text-decoration: none !important;
        transition: background 0.2s;
    }
    .user-profile-sidebar:hover {
        background-color: rgba(255, 255, 255, 0.05);
    }

    .list-group-item-action {
        border: none !important;
        padding: 0.75rem 1.25rem;
        font-size: 14px;
        font-weight: 500;
        color: rgba(255, 255, 255, 0.75) !important;
        background: transparent;
        border-radius: 10px;
        margin: 4px 16px;
        width: auto;
        display: flex;
        align-items: center;
        transition: all 0.2s ease;
        text-decoration: none !important;
        cursor: pointer;
    }
    
    .list-group-item-action:hover,
    .list-group-item-action.active-menu {
        background-color: rgba(255, 255, 255, 0.15) !important;
        color: #ffffff !important;
        font-weight: 600;
    }
    
    .list-group-item-action[aria-expanded="true"] {
        background-color: rgba(255, 255, 255, 0.1) !important;
        color: #ffffff !important;
    }
    
    .list-group-item-action i {
        color: rgba(255, 255, 255, 0.75);
    }
    .list-group-item-action:hover i,
    .list-group-item-action.active-menu i,
    .list-group-item-action[aria-expanded="true"] i {
        color: #ffffff !important;
    }

    .submenu-box .list-group-item-action {
        margin: 2px 8px !important;
        padding: 0.6rem 1rem;
        font-size: 13px;
        color: rgba(255, 255, 255, 0.8) !important;
    }
    .submenu-box .list-group-item-action:hover,
    .submenu-box .list-group-item-action.active-submenu {
        background-color: rgba(255, 255, 255, 0.12) !important;
        color: #ffffff !important;
        font-weight: 600;
    }

    .chevron-arrow {
        transition: transform 0.2s ease;
    }
    .list-group-item-action:not(.collapsed) .chevron-arrow {
        transform: rotate(180deg);
    }

    .menu-container-clean {
        -ms-overflow-style: none;
        scrollbar-width: none;
    }
    .menu-container-clean::-webkit-scrollbar {
        display: none;
    }

    .sidebar-footer {
        position: absolute;
        bottom: 0;
        width: 260px;
        padding: 1rem;
        background: #245358;
        border-top: 1px solid rgba(255, 255, 255, 0.08);
    }
</style>

<div id="sidebar-wrapper" class="position-relative d-flex flex-column justify-content-between">
    <div>
        <div class="text-center py-4 border-bottom" style="border-color: rgba(255,255,255,0.1) !important;">
            <h4 class="text-white fw-bold mb-0">
                <i class="fa-solid fa-graduation-cap me-2 text-info"></i>SOBAT IK
            </h4>
        </div>

        <a href="<?= $base_path; ?>kinerja_dosen/profile.php" class="user-profile-sidebar text-center py-3 mb-3 d-block text-decoration-none">
            <img src="https://cdn-icons-png.flaticon.com/512/3135/3135715.png" 
                 class="rounded-circle mb-2" 
                 style="width: 65px; height: 65px; object-fit: cover; border: 3px solid rgba(255,255,255,0.2);">
            
            <div class="user-info">
                <h6 class="text-white mb-0 fw-bold small"><?= htmlspecialchars($nama_dosen_aktif); ?></h6>
                <span class="badge bg-success" style="font-size: 10px; padding: 2px 8px;">Dosen</span>
            </div>
        </a>

        <hr class="sidebar-divider my-2 mx-3" style="border-color: rgba(255,255,255,0.1);">

        <div class="list-group list-group-flush mt-2 menu-container-clean" style="max-height: calc(100vh - 280px); overflow-y: scroll; padding-bottom: 4rem;">
            
            <a href="<?= $is_inside_folder ? '../dashboard.php' : 'dashboard.php'; ?>" class="list-group-item list-group-item-action <?= ($current_page == 'dashboard.php') ? 'active-menu' : ''; ?>">
                <i class="fa-solid fa-chart-pie me-3" style="width: 20px;"></i>Dashboard Utama
            </a>

            <?php $is_akademik_active = ($current_page == 'jadwal.php' || $current_page == 'presensi.php' || $current_page == 'mata_kuliah.php' || $current_page == 'nilai.php'); ?>
            <a class="list-group-item list-group-item-action justify-content-between <?= $is_akademik_active ? '' : 'collapsed'; ?>"
               data-bs-toggle="collapse" data-bs-target="#menuAkademikDosen" role="button" aria-expanded="<?= $is_akademik_active ? 'true' : 'false'; ?>">
                <div class="d-flex align-items-center">
                    <i class="fa-solid fa-layer-group me-3" style="width: 20px;"></i>Akademik Mengajar
                </div>
                <i class="fa-solid fa-chevron-down small chevron-arrow" style="font-size: 10px;"></i>
            </a>
            <div class="collapse <?= $is_akademik_active ? 'show' : ''; ?>" id="menuAkademikDosen" style="background: rgba(0,0,0,0.15); border-radius: 8px; margin: 2px 16px;">
                <div class="nav flex-column pb-1 submenu-box">
                    <a class="list-group-item list-group-item-action <?= ($current_page == 'jadwal.php' || $current_page == 'presensi.php') ? 'active-submenu' : ''; ?>" href="<?= $base_path; ?>akademik_mengajar/jadwal.php"><i class="fa-regular fa-calendar me-2"></i>Jadwal & Absensi</a>
                    <a class="list-group-item list-group-item-action <?= ($current_page == 'mata_kuliah.php') ? 'active-submenu' : ''; ?>" href="<?= $base_path; ?>akademik_mengajar/mata_kuliah.php"><i class="fa-regular fa-file-lines me-2"></i>Materi & Silabus</a>
                    <a class="list-group-item list-group-item-action <?= ($current_page == 'nilai.php') ? 'active-submenu' : ''; ?>" href="<?= $base_path; ?>akademik_mengajar/nilai.php"><i class="fa-regular fa-id-card me-2"></i>Input Nilai Akhir</a>
                </div>
            </div>

            <?php $is_perwalian_active = ($current_page == 'bimbingan.php' || $current_page == 'krs_validasi.php'); ?>
            <a class="list-group-item list-group-item-action justify-content-between <?= $is_perwalian_active ? '' : 'collapsed'; ?>"
               data-bs-toggle="collapse" data-bs-target="#menuPerwalianDosen" role="button" aria-expanded="<?= $is_perwalian_active ? 'true' : 'false'; ?>">
                <div class="d-flex align-items-center">
                    <i class="fa-solid fa-users me-3" style="width: 20px;"></i>Perwalian / PA
                </div>
                <i class="fa-solid fa-chevron-down small chevron-arrow" style="font-size: 10px;"></i>
            </a>
            <div class="collapse <?= $is_perwalian_active ? 'show' : ''; ?>" id="menuPerwalianDosen" style="background: rgba(0,0,0,0.15); border-radius: 8px; margin: 2px 16px;">
                <div class="nav flex-column pb-1 submenu-box">
                    <a class="list-group-item list-group-item-action <?= ($current_page == 'bimbingan.php') ? 'active-submenu' : ''; ?>" href="<?= $base_path; ?>perwalian/bimbingan.php"><i class="fa-solid fa-user-group me-2"></i>Data Mahasiswa PA</a>
                    <a class="list-group-item list-group-item-action <?= ($current_page == 'krs_validasi.php') ? 'active-submenu' : ''; ?>" href="<?= $base_path; ?>perwalian/krs_validasi.php"><i class="fa-solid fa-file-signature me-2"></i>Persetujuan KRS</a>
                </div>
            </div>

            <?php $is_ta_active = ($current_page == 'bimbingan_skripsi.php' || $current_page == 'jadwal_sidang.php'); ?>
            <a class="list-group-item list-group-item-action justify-content-between <?= $is_ta_active ? '' : 'collapsed'; ?>"
               data-bs-toggle="collapse" data-bs-target="#menuTugasAkhirDosen" role="button" aria-expanded="<?= $is_ta_active ? 'true' : 'false'; ?>">
                <div class="d-flex align-items-center">
                    <i class="fa-solid fa-user-shield me-3" style="width: 20px;"></i>Tugas Akhir
                </div>
                <i class="fa-solid fa-chevron-down small chevron-arrow" style="font-size: 10px;"></i>
            </a>
            <div class="collapse <?= $is_ta_active ? 'show' : ''; ?>" id="menuTugasAkhirDosen" style="background: rgba(0,0,0,0.15); border-radius: 8px; margin: 2px 16px;">
                <div class="nav flex-column pb-1 submenu-box">
                    <a class="list-group-item list-group-item-action <?= ($current_page == 'bimbingan_skripsi.php') ? 'active-submenu' : ''; ?>" href="<?= $base_path; ?>tugas_akhir/bimbingan_skripsi.php"><i class="fa-solid fa-book-reader me-2"></i>Bimbingan Skripsi</a>
                    <a class="list-group-item list-group-item-action <?= ($current_page == 'jadwal_sidang.php') ? 'active-submenu' : ''; ?>" href="<?= $base_path; ?>tugas_akhir/jadwal_sidang.php"><i class="fa-solid fa-gavel me-2"></i>Penguji Sidang</a>
                </div>
            </div>

            <?php $is_kinerja_active = ($current_page == 'bkd_lkd.php' || $current_page == 'profile.php'); ?>
            <a class="list-group-item list-group-item-action justify-content-between <?= $is_kinerja_active ? '' : 'collapsed'; ?>"
               data-bs-toggle="collapse" data-bs-target="#menuKinerjaDosen" role="button" aria-expanded="<?= $is_kinerja_active ? 'true' : 'false'; ?>">
                <div class="d-flex align-items-center">
                    <i class="fa-solid fa-user-gear me-3" style="width: 20px;"></i>Kinerja Dosen
                </div>
                <i class="fa-solid fa-chevron-down small chevron-arrow" style="font-size: 10px;"></i>
            </a>
            <div class="collapse <?= $is_kinerja_active ? 'show' : ''; ?>" id="menuKinerjaDosen" style="background: rgba(0,0,0,0.15); border-radius: 8px; margin: 2px 16px;">
                <div class="nav flex-column pb-1 submenu-box">
                    <a class="list-group-item list-group-item-action <?= ($current_page == 'bkd_lkd.php') ? 'active-submenu' : ''; ?>" href="<?= $base_path; ?>kinerja_dosen/bkd_lkd.php"><i class="fa-solid fa-file-invoice me-2"></i>Laporan BKD / LKD</a>
                    <a class="list-group-item list-group-item-action <?= ($current_page == 'profile.php') ? 'active-submenu' : ''; ?>" href="<?= $base_path; ?>kinerja_dosen/profile.php"><i class="fa-solid fa-sliders me-2"></i>Profil & Akun</a>
                </div>
            </div>

        </div>
    </div>

    <div class="sidebar-footer">
        <a href="<?= $is_inside_folder ? '../../auth/logout.php' : '../auth/logout.php'; ?>" class="btn btn-light text-danger w-100 rounded-pill py-2 small fw-bold border-0 d-flex align-items-center justify-content-center gap-2" style="font-size: 12px; background: #fef2f2;">
            <i class="fa-solid fa-right-from-bracket"></i> Keluar Sistem
        </a>
    </div>
</div>

<div id="page-content-wrapper" class="d-flex flex-column flex-grow-1">
    
    <nav class="navbar navbar-expand navbar-light bg-white px-4 py-3 border-bottom shadow-sm" style="min-height: 65px;">
        <div class="container-fluid p-0 d-flex justify-content-between align-items-center">
            
            <span class="navbar-text fw-semibold text-dark">
                <i class="fa-regular fa-calendar-check me-2" style="color: #245358;"></i>
                <?php 
                date_default_timezone_set('Asia/Jakarta');
                $jam = date('H');
                $sapaan = "Selamat Malam";
                if ($jam >= 5 && $jam < 11) $sapaan = "Selamat Pagi";
                elseif ($jam >= 11 && $jam < 15) $sapaan = "Selamat Siang";
                elseif ($jam >= 15 && $jam < 18) $sapaan = "Selamat Sore";
                
                echo $sapaan . ", " . htmlspecialchars($nama_dosen_aktif); 
                ?>
            </span>
            
            <div class="ms-auto">
                <span class="badge border p-2 fw-semibold" style="background-color: #f8f9fa; color: #245358; border-color: rgba(36, 83, 88, 0.2) !important;">
                    <i class="fa-solid fa-graduation-cap me-1"></i> TA: 2026/Ganjil
                </span>
            </div>
        </div>
    </nav>
    
    <div class="container-fluid p-4 flex-grow-1" style="background-color: #f8fafc;">