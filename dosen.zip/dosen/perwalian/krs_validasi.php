<?php
// dosen/perwalian/krs_validasi.php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once __DIR__ . '/../templates/header.php'; 
require_once __DIR__ . '/../templates/sidebar.php'; 
require_once __DIR__ . '/../../config/database.php';

$id_user_dosen = $_SESSION['id_user'] ?? 1;

// Ambil ID Dosen
$query_dosen = mysqli_query($db, "SELECT id_dosen FROM dosen WHERE id_user = '$id_user_dosen'");
$data_dosen = mysqli_fetch_assoc($query_dosen);
$id_dosen = $data_dosen['id_dosen'] ?? 0;

// Eksekusi Tombol Setujui KRS
if (isset($_POST['setujui_krs'])) {
    $id_krs = mysqli_real_escape_string($db, $_POST['id_krs']);
    mysqli_query($db, "UPDATE krs SET status_validasi = 'Disetujui' WHERE id_krs = '$id_krs'");
    echo "<script>alert('KRS Mahasiswa Telah Berhasil Disetujui!'); window.location='krs_validasi.php';</script>";
}

// Ambil data ajuan KRS mahasiswa bimbingan wali aktif
$query_krs = mysqli_query($db, "
    SELECT k.*, m.nama_mhs, m.nim, k.semester
    FROM krs k
    JOIN mahasiswa m ON k.id_mahasiswa = m.id_mahasiswa
    WHERE m.id_dosen_wali = '$id_dosen'
    ORDER BY k.status_validasi ASC, m.nim ASC
");
?>

<div class="row mb-4">
    <div class="col-12">
        <h4 class="fw-bold text-dark mb-1">Validasi & Persetujuan KRS</h4>
        <p class="text-muted small mb-0">Tinjau perencanaan pengambilan SKS mahasiswa bimbingan akademik Anda.</p>
    </div>
</div>

<div class="card border-0 shadow-sm rounded-4 overflow-hidden bg-white">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="bg-light text-secondary small text-uppercase" style="font-size: 11px; letter-spacing: 0.5px;">
                    <tr>
                        <th class="py-3 ps-4">NIM</th>
                        <th>Nama Mahasiswa</th>
                        <th>Semester Ajuan</th>
                        <th>Status Verifikasi</th>
                        <th class="text-center">Tindakan Pembimbing</th>
                    </tr>
                </thead>
                <tbody style="font-size: 14px;">
                    <?php if (mysqli_num_rows($query_krs) > 0): ?>
                        <?php while ($row = mysqli_fetch_assoc($query_krs)): ?>
                            <tr>
                                <td class="py-3 ps-4 font-monospace fw-bold text-secondary"><?= htmlspecialchars($row['nim']); ?></td>
                                <td class="fw-semibold text-dark"><?= htmlspecialchars($row['nama_mhs']); ?></td>
                                <td class="text-dark fw-medium">Semester <?= htmlspecialchars($row['semester']); ?></td>
                                <td>
                                    <?php if ($row['status_validasi'] == 'Disetujui'): ?>
                                        <span class="badge rounded-pill px-3 py-1 font-semibold" style="background-color: #d1e7dd; color: #0f5132;">Disetujui</span>
                                    <?php else: ?>
                                        <span class="badge rounded-pill px-3 py-1 font-semibold" style="background-color: #fff3cd; color: #664d03;">Belum Validasi</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <?php if ($row['status_validasi'] == 'Belum Validasi'): ?>
                                        <form method="POST" action="">
                                            <input type="hidden" name="id_krs" value="<?= $row['id_krs']; ?>">
                                            <button type="submit" name="setujui_krs" class="btn btn-sm btn-success px-3 rounded-3 fw-semibold shadow-sm">
                                                <i class="fa-solid fa-check-double me-1"></i> Setujui KRS
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <button class="btn btn-sm btn-light border text-muted px-3 rounded-3 disabled"><i class="fa-solid fa-circle-check text-success me-1"></i> Selesai disetujui</button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="text-center py-5 text-muted">
                                <i class="fa-solid fa-inbox fa-2x mb-2" style="opacity: 0.3;"></i>
                                <p class="mb-0 small">Belum ada ajuan pengisian KRS dari mahasiswa perwalian Anda.</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>